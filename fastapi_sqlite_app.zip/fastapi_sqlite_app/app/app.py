from fastapi import FastAPI, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from .database import get_db
from . import schemas, crud, models

app = FastAPI(title="Demo FastAPI + SQLite", version="1.0.0")

@app.get("/", tags=["root"])
def root():
    return {"message": "API lista. Visita /docs para probar."}

@app.get("/items", response_model=list[schemas.ItemOut], tags=["items"])
def list_items(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)):
    return crud.list_items(db, skip=skip, limit=limit)

@app.get("/items/{item_id}", response_model=schemas.ItemOut, tags=["items"])
def get_item(item_id: int, db: Session = Depends(get_db)):
    item = crud.get_item(db, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item no encontrado")
    return item

@app.post("/items", response_model=schemas.ItemOut, status_code=201, tags=["items"])
def create_item(body: schemas.ItemCreate, db: Session = Depends(get_db)):
    item = crud.create_item(db, body)
    return item

@app.put("/items/{item_id}", response_model=schemas.ItemOut, tags=["items"])
def update_item(item_id: int, body: schemas.ItemUpdate, db: Session = Depends(get_db)):
    item = crud.get_item(db, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item no encontrado")
    return crud.update_item(db, item, body)

@app.delete("/items/{item_id}", status_code=204, tags=["items"])
def delete_item(item_id: int, db: Session = Depends(get_db)):
    item = crud.get_item(db, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item no encontrado")
    crud.delete_item(db, item)
    return None
