from sqlalchemy.orm import Session
from sqlalchemy import select
from . import models, schemas

def get_item(db: Session, item_id: int) -> models.Item | None:
    return db.get(models.Item, item_id)

def list_items(db: Session, skip: int = 0, limit: int = 100) -> list[models.Item]:
    stmt = select(models.Item).offset(skip).limit(limit)
    return list(db.execute(stmt).scalars())

def create_item(db: Session, data: schemas.ItemCreate) -> models.Item:
    item = models.Item(**data.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item

def update_item(db: Session, item: models.Item, data: schemas.ItemUpdate) -> models.Item:
    for k, v in data.model_dump().items():
        setattr(item, k, v)
    db.commit()
    db.refresh(item)
    return item

def delete_item(db: Session, item: models.Item) -> None:
    db.delete(item)
    db.commit()
